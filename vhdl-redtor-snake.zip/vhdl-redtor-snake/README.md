# Retro Snake
Made with VHDL and Nexis 2

Demo video: [link](https://s3-eu-west-1.amazonaws.com/videos-eu-west-1.spliceapp.com/prod/BB408B49-A5D2-4FB8-9DFE-48DEE90A1833/Vb5wED_hls/hls_index.m3u8)

Copy of original project is in ZIP file.

## Interesting

FPGA in Azure https://channel9.msdn.com/Events/Build/2017/B8063